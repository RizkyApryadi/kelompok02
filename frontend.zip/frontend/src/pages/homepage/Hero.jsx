import { useEffect, useState } from "react";

const Hero = () => {
  const [isBlackBg, setIsBlackBg] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setIsBlackBg((prev) => !prev);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="relative">
      <section
        className={`transition-colors duration-1000 ${
          isBlackBg ? "bg-[#070335]" : "bg-[#F0A8C2]"
        } text-white py-0 px-6 min-h-screen`}
      >
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-8 md:gap-16 h-full">
          {/* Konten Kiri */}
          <div className="md:w-1/2 text-center md:text-left mt-40"> {/* Menurunkan margin atas ke mt-40 */}
            <h1
              className={`text-4xl md:text-5xl lg:text-6xl font-bold font-sourceSerif leading-tight tracking-tight transition-colors duration-1000 ${
                isBlackBg ? "text-white" : "text-black"
              }`}
            >
              Belajar Hari Ini, <br /> Pemimpin Esok Hari
            </h1>

            <p
              className={`mt-4 text-lg md:text-xl lg:text-2xl font-medium transition-colors duration-1000 ${
                isBlackBg ? "text-gray-300" : "text-gray-800"
              }`}
            >
              ─── SMAN 1 PARMAKSIAN
            </p>
          </div>

          {/* Avatar dalam Lingkaran */}
          <div className="relative w-[40vw] h-[40vw] md:w-[30vw] md:h-[30vw] lg:w-[25vw] lg:h-[25vw] flex items-center justify-center mt-40"> {/* Menurunkan margin atas ke mt-40 */}
            <div className="absolute w-28 h-28 md:w-36 md:h-36 lg:w-48 lg:h-48 bg-[#FFFFFF] rounded-full flex items-center justify-center z-10 shadow-xl">
              <img
                src="./images/main.svg"
                alt="Avatar Main"
                className="w-20 h-20 md:w-28 md:h-28 lg:w-36 lg:h-36 object-cover rounded-full"
              />
            </div>
            <div className="absolute w-24 h-24 md:w-32 md:h-32 lg:w-40 lg:h-40 bg-[#F9A8D4] rounded-full top-0 left-0 flex items-center justify-center z-0">
              <img
                src="./images/12.svg"
                alt="Avatar 1"
                className="w-20 h-20 md:w-28 md:h-28 lg:w-36 lg:h-36 object-cover rounded-full"
              />
            </div>
            <div className="absolute w-20 h-20 md:w-28 md:h-28 lg:w-36 lg:h-36 bg-[#C4A2F7] rounded-full top-4 right-0 flex items-center justify-center z-0">
              <img
                src="./images/2.svg"
                alt="Avatar 2"
                className="w-16 h-16 md:w-24 md:h-24 lg:w-32 lg:h-32 object-cover rounded-full"
              />
            </div>
            <div className="absolute w-20 h-20 md:w-28 md:h-28 lg:w-36 lg:h-36 bg-[#FDE68A] rounded-full bottom-8 right-4 flex items-center justify-center z-0">
              <img
                src="./images/3.svg"
                alt="Avatar 3"
                className="w-14 h-14 md:w-24 md:h-24 lg:w-28 lg:h-28 object-cover rounded-full"
              />
            </div>
          </div>
        </div>

      </section>
      <hr />
    </div>
  );
};

export default Hero;
