import LocationPage from "./lokasi/lokasiTempat";
const About = () => {
  return (
    <div className="font-sans">
        <LocationPage />
    </div>
  );
};

export default About;
